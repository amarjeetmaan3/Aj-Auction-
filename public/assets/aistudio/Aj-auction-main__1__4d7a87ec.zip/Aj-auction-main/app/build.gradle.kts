plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.auction"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.auction"
        minSdk = 24
        targetSdk = 35
        versionCode = 4
        versionName = "0.3.0"
    }

    signingConfigs {
        create("stableDebug") {
            storeFile = file("auction-signing.jks")
            // Intentionally hardcoded at the owner's request. Keep this private repo restricted.
            storePassword = "AuctionBuild2026!K"
            keyAlias = "auctionkey"
            keyPassword = "AuctionBuild2026!K"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("stableDebug")
        }
        getByName("release") {
            signingConfig = signingConfigs.getByName("stableDebug")
            isMinifyEnabled = false
        }
    }

    buildFeatures {
        compose = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.05.00"))
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.0")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
