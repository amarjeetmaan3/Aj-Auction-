package com.example.auction

import android.os.Bundle
import android.net.Uri
import android.app.DownloadManager
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import org.json.JSONArray
import org.json.JSONObject
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.width
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.alpha
import com.example.auction.data.AuctionPlayer
import com.example.auction.data.AuctionTeam
import com.example.auction.data.AuctionConfig
import com.example.auction.data.PlayerStatus
import com.example.auction.data.AuctionSnapshot

private enum class AppTab(val title: String, val symbol: String) {
    // Keep the operator workflow aligned with the original HTML: configure first,
    // then teams and players, then run the auction and review results.
    SETTINGS("Settings", "⚙"), TEAMS("Teams", "🛡"), PLAYERS("Players", "🏏"),
    AUCTION("Auction", "🔨"), SOLD("Results", "🏆"), HOME("Team Status", "📊"),
    APP("App", "ⓘ"), TEAM_DETAIL("Team", "🛡")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(
                primary = Color(0xFF07543D), onPrimary = Color(0xFFFFFFFF), primaryContainer = Color(0xFFBCE8D0), onPrimaryContainer = Color(0xFF063B2C), secondary = Color(0xFFFFC247), onSecondary = Color(0xFF3C2A00), secondaryContainer = Color(0xFFFFE8A8), onSecondaryContainer = Color(0xFF4D3500), tertiary = Color(0xFFB93432), onTertiary = Color(0xFFFFFFFF), tertiaryContainer = Color(0xFFFFDAD5), onTertiaryContainer = Color(0xFF5B1114), background = Color(0xFFF2F6EF), onBackground = Color(0xFF15251D), surface = Color(0xFFFFFEFA), onSurface = Color(0xFF15251D), surfaceVariant = Color(0xFFE1ECE2), onSurfaceVariant = Color(0xFF405449), outline = Color(0xFFB9CBBE), error = Color(0xFFB3261E), errorContainer = Color(0xFFFFDAD6)
            )) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { AuctionApp() }
            }
        }
    }
}

private data class LeagueInfo(val id: String, val name: String)

private object LeagueDirectory {
    private const val PREFS = "aj_auction_league_directory"
    private const val KEY = "leagues"

    fun load(context: android.content.Context): List<LeagueInfo> {
        val prefs = context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY, null)
        if (raw != null) return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { i ->
                val item = array.optJSONObject(i) ?: return@mapNotNull null
                val id = item.optString("id").takeIf { it.isNotBlank() } ?: return@mapNotNull null
                val name = item.optString("name").takeIf { it.isNotBlank() } ?: "Untitled league"
                LeagueInfo(id, name)
            }
        }.getOrDefault(emptyList())
        // Preserve the existing single-league data as the first league; no old preferences are deleted.
        val initial = listOf(LeagueInfo("legacy-default", "My League"))
        save(context, initial)
        return initial
    }

    fun save(context: android.content.Context, leagues: List<LeagueInfo>) {
        val array = JSONArray()
        leagues.forEach { league -> array.put(JSONObject().put("id", league.id).put("name", league.name)) }
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
            .edit().putString(KEY, array.toString()).apply()
    }
}

@Composable
private fun AuctionApp() {
    val context = LocalContext.current
    var leagues by remember { mutableStateOf(LeagueDirectory.load(context)) }
    var activeLeagueId by rememberSaveable { mutableStateOf<String?>(null) }
    var newLeagueName by rememberSaveable { mutableStateOf("") }
    var renameId by rememberSaveable { mutableStateOf<String?>(null) }
    var renameValue by rememberSaveable { mutableStateOf("") }
    var pendingDeleteLeagueId by rememberSaveable { mutableStateOf<String?>(null) }
    var notice by remember { mutableStateOf("") }
    var landingMode by rememberSaveable { mutableStateOf("home") }
    var openLeagueStartsAtAuction by rememberSaveable { mutableStateOf(false) }

    val activeLeague = leagues.firstOrNull { it.id == activeLeagueId }
    if (activeLeague != null) {
        key(activeLeague.id) {
            LeagueWorkspace(
                leagueId = activeLeague.id,
                leagueName = activeLeague.name,
                initialTab = if (openLeagueStartsAtAuction) AppTab.AUCTION else AppTab.SETTINGS,
                onBack = { activeLeagueId = null; landingMode = "home" }
            )
        }
        return
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().imePadding().padding(18.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF063D2C), Color(0xFF08764E), Color(0xFF153D32))), RoundedCornerShape(22.dp)).padding(20.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("🏏  AJ AUCTION", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = Color.White)
                Text("CRICKET LEAGUE MANAGER", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = Color(0xFFFFD36A))
                Text("Build your teams. Run your auction.", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFE0F2E5))
            }
        }
        if (landingMode == "home") {
            Text("Choose what you want to do. Leagues and auction data are saved on this device; no login or internet is required.")
            Button(onClick = { landingMode = "create"; notice = "" }, modifier = Modifier.fillMaxWidth()) {
                Text("＋  Create League")
            }
            OutlinedButton(onClick = { landingMode = "load"; notice = "" }, modifier = Modifier.fillMaxWidth()) {
                Text("▣  Load League")
            }
        } else {
            if (landingMode == "create") {
                TextButton(onClick = { landingMode = "home"; notice = "" }) { Text("‹ Back") }
                Text("Create a new league", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = newLeagueName,
                    onValueChange = { newLeagueName = it.take(60) },
                    label = { Text("League name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Button(
                    onClick = {
                        val name = newLeagueName.trim()
                        if (name.isNotBlank() && leagues.none { it.name.equals(name, ignoreCase = true) }) {
                            val league = LeagueInfo("league-" + java.util.UUID.randomUUID().toString(), name)
                            leagues = leagues + league
                            LeagueDirectory.save(context, leagues)
                            newLeagueName = ""
                            notice = "League created. Configure it to continue."
                            openLeagueStartsAtAuction = false
                            activeLeagueId = league.id
                        } else notice = "Enter a unique league name."
                    },
                    enabled = newLeagueName.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Create and Configure") }
            } else {
                Text("Select a saved league to continue directly to Live Auction.", style = MaterialTheme.typography.bodyMedium)
                if (leagues.isEmpty()) Text("No saved leagues yet. Use Create League first.")
                leagues.forEach { league ->
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(league.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = {
                                    openLeagueStartsAtAuction = true
                                    activeLeagueId = league.id
                                }, modifier = Modifier.weight(1f)) { Text("Load League · Live Auction") }
                                TextButton(onClick = { renameId = league.id; renameValue = league.name }) { Text("Rename") }
                                TextButton(onClick = { pendingDeleteLeagueId = league.id }) { Text("Delete League") }
                            }
                        }
                    }
                }
            }
        }
        if (notice.isNotBlank()) Text(notice, style = MaterialTheme.typography.bodySmall)
    }

    if (pendingDeleteLeagueId != null) {
        val deleteId = pendingDeleteLeagueId
        val deleteLeague = leagues.firstOrNull { it.id == deleteId }
        AlertDialog(
            onDismissRequest = { pendingDeleteLeagueId = null },
            title = { Text("Delete league permanently?") },
            text = { Text("This deletes the league from this device, including its saved teams, players, auction results and undo history. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    if (deleteId != null) {
                        AuctionLocalStore.deleteLeagueData(context, deleteId)
                        leagues = leagues.filterNot { it.id == deleteId }
                        LeagueDirectory.save(context, leagues)
                        if (activeLeagueId == deleteId) activeLeagueId = null
                        if (renameId == deleteId) renameId = null
                        notice = "League and its saved data deleted."
                    }
                    pendingDeleteLeagueId = null
                }) { Text("Delete permanently") }
            },
            dismissButton = { TextButton(onClick = { pendingDeleteLeagueId = null }) { Text("Cancel") } }
        )
    }

    if (renameId != null) {
        AlertDialog(
            onDismissRequest = { renameId = null },
            title = { Text("Rename league") },
            text = {
                OutlinedTextField(
                    value = renameValue,
                    onValueChange = { renameValue = it.take(60) },
                    label = { Text("League name") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val id = renameId
                    val clean = renameValue.trim()
                    if (id != null && clean.isNotBlank() && leagues.none { it.id != id && it.name.equals(clean, true) }) {
                        leagues = leagues.map { if (it.id == id) it.copy(name = clean) else it }
                        LeagueDirectory.save(context, leagues)
                        notice = "League renamed."
                        renameId = null
                    } else notice = "Enter a unique league name."
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { renameId = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun LeagueWorkspace(leagueId: String, leagueName: String, initialTab: AppTab, onBack: () -> Unit) {
    val context = LocalContext.current
    val restored = remember(leagueId) { AuctionLocalStore.load(context, leagueId) }
    var selectedTab by rememberSaveable(leagueId, initialTab) { mutableStateOf(initialTab) }
    var selectedTeamId by rememberSaveable { mutableStateOf<String?>(null) }
    var appMenuExpanded by remember { mutableStateOf(false) }
    var config by remember { mutableStateOf(restored.config) }
    val players = remember { mutableStateListOf<AuctionPlayer>().apply { addAll(restored.players) } }
    val teams = remember { mutableStateListOf<AuctionTeam>().apply { addAll(restored.teams) } }
    val history = remember(leagueId) { mutableStateListOf<AuctionSnapshot>().apply { addAll(AuctionLocalStore.loadHistory(context, leagueId)) } }
    var bidCounter by remember { mutableStateOf(restored.bidCounter) }
    var retentionCounter by remember { mutableStateOf(restored.retentionCounter) }
    var roundNumber by remember { mutableStateOf(restored.roundNumber) }
    var backupNotice by remember { mutableStateOf("") }
    var pendingBackupJson by remember { mutableStateOf<String?>(null) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val backup = pendingBackupJson
        if (uri != null && backup != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(backup) }
                    ?: error("Could not write backup file")
            }.onSuccess { backupNotice = "Backup file saved successfully." }
                .onFailure { backupNotice = "Could not save backup file." }
        } else if (uri == null) {
            backupNotice = "Backup export cancelled."
        }
        pendingBackupJson = null
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: error("Could not read backup file")
            }.onSuccess { raw ->
                val imported = AuctionLocalStore.parseBackup(raw)
                if (imported == null) backupNotice = "Backup file is invalid or unsupported."
                else {
                    val duplicatePlayerNumbers = imported.players.groupingBy { it.number }.eachCount().filterValues { it > 1 }.keys
                    val duplicateTeamIds = imported.teams.groupingBy { it.id }.eachCount().filterValues { it > 1 }.keys
                    val teamIds = imported.teams.map { it.id }.toSet()
                    val invalidPlayers = imported.players.any {
                        it.number <= 0 || it.name.isBlank() || !it.price.isFinite() || it.price < 0 ||
                            (it.teamId != null && it.teamId !in teamIds) ||
                            ((it.status == PlayerStatus.SOLD || it.status == PlayerStatus.RETAINED) && it.teamId == null)
                    }
                    val invalidTeams = imported.teams.any {
                        it.id.isBlank() || it.name.isBlank() || it.shortName.isBlank() ||
                            !it.startingPoints.isFinite() || it.startingPoints < 0 ||
                            !it.pointsSpent.isFinite() || it.pointsSpent < 0 ||
                            it.playerCount < 0 || it.retainedCount < 0
                    }
                    val invalidConfig = imported.config.playersPerTeam <= 0 || imported.config.teamCount <= 0 ||
                        !imported.config.basePrice.isFinite() || imported.config.basePrice < 0 ||
                        !imported.config.startingPoints.isFinite() || imported.config.startingPoints < 0 ||
                        imported.config.maxRetentions < 0 || !imported.config.retentionCost.isFinite() ||
                        imported.config.retentionCost < 0
                    if (duplicatePlayerNumbers.isNotEmpty()) {
                        backupNotice = "Backup rejected: duplicate player numbers (${duplicatePlayerNumbers.sorted().joinToString()})."
                    } else if (duplicateTeamIds.isNotEmpty()) {
                        backupNotice = "Backup rejected: duplicate team IDs."
                    } else if (invalidPlayers || invalidTeams || invalidConfig) {
                        backupNotice = "Backup rejected: it contains invalid player assignments, team data, or auction settings."
                    } else {
                        history.add(AuctionSnapshot(players.toList(), teams.toList(), bidCounter, retentionCounter, roundNumber))
                        if (history.size > 50) history.removeAt(0)
                        AuctionLocalStore.saveHistory(context, leagueId, history.toList())
                        players.clear(); players.addAll(imported.players)
                        teams.clear(); teams.addAll(imported.teams)
                        config = imported.config
                        bidCounter = imported.bidCounter
                        retentionCounter = imported.retentionCounter
                        roundNumber = imported.roundNumber
                        backupNotice = "Backup restored successfully. Previous state saved for Undo."
                    }
                }
            }.onFailure { backupNotice = "Could not restore backup file." }
        }
    }
    LaunchedEffect(players.toList(), teams.toList(), config, bidCounter, retentionCounter, roundNumber) {
        AuctionLocalStore.save(context, leagueId, players.toList(), teams.toList(), config, bidCounter, retentionCounter, roundNumber)
    }
    fun saveSnapshot() {
        history.add(AuctionSnapshot(players.toList(), teams.toList(), bidCounter, retentionCounter, roundNumber))
        if (history.size > 50) history.removeAt(0)
        AuctionLocalStore.saveHistory(context, leagueId, history.toList())
    }
    fun undoLastAction() {
        val snapshot = history.removeLastOrNull() ?: return
        AuctionLocalStore.saveHistory(context, leagueId, history.toList())
        players.clear()
        players.addAll(snapshot.players)
        teams.clear()
        teams.addAll(snapshot.teams)
        bidCounter = snapshot.bidCounter
        retentionCounter = snapshot.retentionCounter
        roundNumber = snapshot.roundNumber
    }
    // Same as the HTML: every unsold player goes back to the pending pool and the round number increases.
    fun startNextRound() {
        if (players.none { it.status == PlayerStatus.UNSOLD }) return
        saveSnapshot()
        players.indices.forEach { index ->
            val p = players[index]
            if (p.status == PlayerStatus.UNSOLD) players[index] = p.copy(status = PlayerStatus.PENDING, auctionTurn = null)
        }
        roundNumber += 1
    }
    // Same rules as the HTML retain box: pending player, free retain slot, enough points, squad not full.
    fun retainPlayer(teamId: String, playerNumber: Int): String {
        val ti = teams.indexOfFirst { it.id == teamId }
        val pi = players.indexOfFirst { it.number == playerNumber }
        if (ti < 0 || pi < 0) return "Player not found."
        val team = teams[ti]
        val p = players[pi]
        if (p.status != PlayerStatus.PENDING) return "Player is not available."
        if (team.retainedCount >= config.maxRetentions) return "No retain slots left for ${team.name}."
        if (team.pointsRemaining < config.retentionCost) return "${team.name} cannot afford the retain cost."
        if (team.playerCount >= config.playersPerTeam) return "${team.name}'s squad is full."
        if (!AuctionRules.canRetain(p, team, config)) return "Retain is not allowed."
        saveSnapshot()
        retentionCounter += 1
        players[pi] = p.copy(
            status = PlayerStatus.RETAINED, teamId = team.id, price = config.retentionCost,
            auctionTurn = retentionCounter, auctionRound = null
        )
        teams[ti] = team.copy(
            pointsSpent = team.pointsSpent + config.retentionCost,
            playerCount = team.playerCount + 1,
            retainedCount = team.retainedCount + 1
        )
        return "${p.name} retained by ${team.name}."
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Row(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF063D2C), Color(0xFF08764E), Color(0xFF123D32)))).statusBarsPadding().padding(horizontal = 4.dp, vertical = 5.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("‹ Leagues", color = androidx.compose.ui.graphics.Color.White) }
                Column(Modifier.weight(1f)) {
                    Text("AJ AUCTION", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black,
                        color = androidx.compose.ui.graphics.Color.White, maxLines = 1)
                    Text(leagueName, style = MaterialTheme.typography.bodySmall, color = androidx.compose.ui.graphics.Color(0xFFDCE8FF), maxLines = 1)
                }
                androidx.compose.foundation.layout.Box {
                    TextButton(onClick = { appMenuExpanded = true }) { Text("⋮", style = MaterialTheme.typography.titleLarge, color = androidx.compose.ui.graphics.Color.White) }
                    DropdownMenu(expanded = appMenuExpanded, onDismissRequest = { appMenuExpanded = false }) {
                        DropdownMenuItem(text = { Text("App information") }, onClick = {
                            appMenuExpanded = false
                            selectedTab = AppTab.APP
                        })
                        DropdownMenuItem(text = { Text("Privacy policy") }, onClick = {
                            appMenuExpanded = false
                            selectedTab = AppTab.APP
                        })
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF082F24),
                contentColor = MaterialTheme.colorScheme.primary,
                tonalElevation = 6.dp
            ) {
                AppTab.entries.filter { it != AppTab.APP && it != AppTab.TEAM_DETAIL }.forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = { Text(tab.symbol, fontSize = 17.sp, maxLines = 1) },
                        label = { Text(tab.title, maxLines = 1, fontSize = 9.sp, fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Medium) },
                        colors = androidx.compose.material3.NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF082F24),
                            selectedTextColor = Color.White,
                            unselectedIconColor = Color(0xFFD2E8DC),
                            unselectedTextColor = Color(0xFFF0F7F3),
                            indicatorColor = Color(0xFFFFD166)
                        )
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).consumeWindowInsets(padding).imePadding().padding(horizontal = 12.dp)) {
            when (selectedTab) {
                AppTab.HOME -> TeamStatusScreen(teams, players, config) { team ->
                    selectedTeamId = team.id
                    selectedTab = AppTab.TEAM_DETAIL
                }
                AppTab.TEAMS -> TeamsScreen(
                    teams = teams,
                    players = players,
                    config = config,
                    onContinue = { if (teams.size == config.teamCount) selectedTab = AppTab.PLAYERS },
                    onAdd = { if (AuctionRules.canAddTeam(teams.size, config)) { saveSnapshot(); teams.add(it) } },
                    onUpdate = { id, name, shortName, colorHex ->
                        val index = teams.indexOfFirst { it.id == id }
                        if (index >= 0 && (teams[index].name != name || teams[index].shortName != shortName || teams[index].colorHex != colorHex)) { saveSnapshot(); teams[index] = teams[index].copy(name = name, shortName = shortName, colorHex = colorHex) }
                    },
                    onDelete = { id ->
                        val hasPlayers = players.any { it.teamId == id && (it.status == PlayerStatus.SOLD || it.status == PlayerStatus.RETAINED) }
                        if (!hasPlayers) {
                            saveSnapshot()
                            players.indices.forEach { index ->
                                if (players[index].teamId == id) players[index] = players[index].copy(teamId = null)
                            }
                            teams.removeAll { it.id == id }
                            if (selectedTeamId == id) selectedTeamId = null
                        }
                    }
                )
                AppTab.PLAYERS -> PlayersScreen(
                    players = players,
                    gradesEnabled = config.enablePlayerGrades,
                    onAdd = { name, number, grade, role, phone, photoUrl ->
                        if (players.none { it.number == number }) { saveSnapshot(); players.add(AuctionPlayer(number = number, name = name.trim(), grade = grade.trim().ifBlank { null }, role = role.trim().ifBlank { null }, phone = phone.trim().ifBlank { null }, photoUrl = photoUrl.trim().ifBlank { null })) }
                    },
                    onUpdate = { oldNumber, name, number, grade, role, phone, photoUrl ->
                        val index = players.indexOfFirst { it.number == oldNumber }
                        if (index >= 0 && players.none { it.number == number && it.number != oldNumber }) {
                            val updatedPlayer = players[index].copy(number = number, name = name.trim(), grade = grade.trim().ifBlank { null }, role = role.trim().ifBlank { null }, phone = phone.trim().ifBlank { null }, photoUrl = photoUrl.trim().ifBlank { null })
                            if (updatedPlayer != players[index]) { saveSnapshot(); players[index] = updatedPlayer }
                        }
                    },
                    onDelete = { number ->
                        val index = players.indexOfFirst { it.number == number }
                        if (index >= 0) {
                            saveSnapshot()
                            val player = players[index]
                            val teamIndex = teams.indexOfFirst { it.id == player.teamId }
                            if (teamIndex >= 0 && player.status in listOf(PlayerStatus.SOLD, PlayerStatus.RETAINED)) {
                                val team = teams[teamIndex]
                                val cost = if (player.status == PlayerStatus.RETAINED) config.retentionCost else player.price
                                teams[teamIndex] = team.copy(
                                    pointsSpent = (team.pointsSpent - cost).coerceAtLeast(0.0),
                                    playerCount = (team.playerCount - 1).coerceAtLeast(0),
                                    retainedCount = if (player.status == PlayerStatus.RETAINED) (team.retainedCount - 1).coerceAtLeast(0) else team.retainedCount
                                )
                            }
                            players.removeAt(index)
                        }
                    },
                    onContinue = { selectedTab = AppTab.AUCTION }
                )
                AppTab.AUCTION -> AuctionScreen(players, teams, config, history.isNotEmpty(), roundNumber, ::saveSnapshot, ::undoLastAction, { bidCounter += 1; bidCounter }, ::startNextRound)
                AppTab.SOLD -> SoldScreen(players, teams)
                AppTab.APP -> AppToolsScreen(players.toList(), teams.toList(), config)
                AppTab.TEAM_DETAIL -> {
                    val selectedTeam = teams.firstOrNull { it.id == selectedTeamId }
                    if (selectedTeam == null) Text("Choose a team tab above.")
                    else TeamDetailScreen(selectedTeam, players, config, onRetain = { number -> retainPlayer(selectedTeam.id, number) }) { selectedTab = AppTab.AUCTION }
                }
                AppTab.SETTINGS -> SettingsScreen(config) { updated ->
                    config = updated
                    teams.indices.forEach { index ->
                        val t = teams[index]
                        if (t.playerCount == 0 && t.pointsSpent == 0.0) {
                            teams[index] = t.copy(startingPoints = updated.startingPoints)
                        }
                    }
                    selectedTab = AppTab.TEAMS
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(playerCount: Int, teamCount: Int, config: AuctionConfig) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF06432F), Color(0xFF0B7952), Color(0xFF163F32))), RoundedCornerShape(20.dp)).padding(18.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("AJ AUCTION", style = MaterialTheme.typography.labelLarge, color = Color(0xFFFFD36A), fontWeight = FontWeight.Black)
                Text("Auction dashboard", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black, color = Color.White)
                Text("THE GAME. THE TEAMS. THE MOMENT.", style = MaterialTheme.typography.labelSmall, color = Color(0xFFD6F0E1), fontWeight = FontWeight.Bold)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SummaryCard("Teams", teamCount.toString(), Modifier.weight(1f))
            SummaryCard("Players", playerCount.toString(), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SummaryCard("Base price", config.basePrice.toString(), Modifier.weight(1f))
            SummaryCard("Team budget", config.startingPoints.toString(), Modifier.weight(1f))
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Native app foundation", fontWeight = FontWeight.Bold)
                Text("This is a native Android Compose app. Teams, players, auction results and league settings are saved on this device and restored when you reopen the app.")
            }
        }
    }
}

@Composable
private fun SummaryCard(label: String, value: String, modifier: Modifier = Modifier) {
    val accent = when (label.lowercase()) {
        "teams", "balance" -> Color(0xFFD8EBDD)
        "players", "retained", "spent" -> Color(0xFFD1EEE7)
        "base price", "max next bid" -> Color(0xFFFFE7B5)
        else -> Color(0xFFFFDCD4)
    }
    Card(
        modifier,
        colors = CardDefaults.cardColors(containerColor = accent),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
    }
}

private fun parseCsvRow(line: String): List<String> {
    val cells = mutableListOf<String>()
    val cell = StringBuilder()
    var quoted = false
    var i = 0
    while (i < line.length) {
        val ch = line[i]
        when {
            ch == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> {
                cell.append('"')
                i++
            }
            ch == '"' -> quoted = !quoted
            ch == ',' && !quoted -> {
                cells.add(cell.toString())
                cell.setLength(0)
            }
            else -> cell.append(ch)
        }
        i++
    }
    cells.add(cell.toString())
    return cells
}

@Composable
private fun PlayersScreen(players: List<AuctionPlayer>, gradesEnabled: Boolean, onAdd: (String, Int, String, String, String, String) -> Unit, onUpdate: (Int, String, Int, String, String, String, String) -> Unit, onDelete: (Int) -> Unit, onContinue: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var number by remember { mutableStateOf("") }
    var grade by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var photoUrl by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var editingNumber by remember { mutableStateOf<Int?>(null) }
    var gridMode by remember { mutableStateOf(true) }
    var importNotice by remember { mutableStateOf("") }
    var formNotice by remember { mutableStateOf("") }
    var pendingDeleteNumber by remember { mutableStateOf<Int?>(null) }
    val context = LocalContext.current
    val csvImportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                var invalidRows = 0
                val rows = context.contentResolver.openInputStream(uri)?.bufferedReader()?.useLines { lines ->
                    lines.toList().mapIndexedNotNull { index, line ->
                        if (line.isBlank()) return@mapIndexedNotNull null
                        val cells = parseCsvRow(line).map { it.trim() }
                        val numberCell = cells.firstOrNull().orEmpty().removePrefix("\uFEFF")
                        val playerName = cells.getOrNull(1).orEmpty()
                        if (index == 0 && (numberCell.contains("number", true) || playerName.contains("name", true))) null
                        else {
                            val n = numberCell.toIntOrNull()
                            if (cells.size < 2 || n == null || n <= 0 || playerName.isBlank()) {
                                invalidRows++
                                null
                            } else Triple(n, playerName, listOf(cells.getOrNull(2).orEmpty(), cells.getOrNull(3).orEmpty(), cells.getOrNull(4).orEmpty(), cells.getOrNull(5).orEmpty()))
                        }
                    }
                } ?: error("Could not read selected file")
                rows to invalidRows
            }.onSuccess { (rows, invalidRows) ->
                var added = 0
                var duplicateInFile = 0
                var alreadyExists = 0
                val seenNumbers = mutableSetOf<Int>()
                rows.forEach { (n, playerName, extra) ->
                    if (!seenNumbers.add(n)) {
                        duplicateInFile++
                    } else if (players.any { it.number == n }) {
                        alreadyExists++
                    } else {
                        onAdd(playerName, n, extra[0], extra[1], extra[2], extra[3])
                        added++
                    }
                }
                val skipped = duplicateInFile + alreadyExists
                importNotice = "CSV import finished: $added added, $skipped skipped ($duplicateInFile duplicate in file, $alreadyExists already in app), $invalidRows invalid rows. Format: number,name,grade,role,phone,photoUrl."
            }.onFailure { importNotice = "Could not import CSV: " + (it.message ?: "file error") }
        }
    }
    val filtered = players.filter {
        it.name.contains(search, ignoreCase = true) ||
            it.number.toString().contains(search) ||
            (it.grade ?: "").contains(search, ignoreCase = true) ||
            (it.role ?: "").contains(search, ignoreCase = true) ||
            (it.phone ?: "").contains(search, ignoreCase = true)
    }
    val listState = rememberLazyListState()
    val uiScope = androidx.compose.runtime.rememberCoroutineScope()
    val startEdit: (AuctionPlayer) -> Unit = { player ->
        editingNumber = player.number; name = player.name; number = player.number.toString()
        grade = player.grade.orEmpty(); role = player.role.orEmpty(); phone = player.phone.orEmpty(); photoUrl = player.photoUrl.orEmpty()
        uiScope.launch { listState.animateScrollToItem(0) }
    }
    LazyColumn(Modifier.fillMaxSize(), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Players", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                OutlinedTextField(name, { name = it }, label = { Text("Player name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(number, { number = it.filter(Char::isDigit).take(4) }, label = { Text("Player number") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                if (gradesEnabled) OutlinedTextField(grade, { grade = it.take(30) }, label = { Text("Player grade (optional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(role, { role = it.take(40) }, label = { Text("Playing role (optional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(phone, { phone = it.take(24) }, label = { Text("Phone number (optional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(photoUrl, { photoUrl = it.take(1000) }, label = { Text("Player photo URL (optional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { csvImportLauncher.launch(arrayOf("text/*", "text/csv", "application/csv", "application/octet-stream")) },
                    modifier = Modifier.fillMaxWidth()) { Text("Import players from CSV") }
                Text("CSV columns: number,name,grade,role,phone,photoUrl (first two are required).", style = MaterialTheme.typography.bodySmall)
                if (importNotice.isNotBlank()) Text(importNotice, style = MaterialTheme.typography.bodySmall)
                Button(onClick = {
                    val n = number.toIntOrNull()
                    val oldNumber = editingNumber
                    when {
                        name.isBlank() -> formNotice = "Enter the player's name."
                        n == null || n <= 0 -> formNotice = "Player number must be a positive whole number."
                        players.any { it.number == n && it.number != oldNumber } -> formNotice = "That player number is already in use."
                        else -> {
                            if (oldNumber == null) {
                                onAdd(name.trim(), n, grade.trim(), role.trim(), phone.trim(), photoUrl.trim())
                                formNotice = "Player added."
                            } else {
                                onUpdate(oldNumber, name.trim(), n, grade.trim(), role.trim(), phone.trim(), photoUrl.trim())
                                formNotice = "Player changes saved."
                            }
                            name = ""; number = ""; grade = ""; role = ""; phone = ""; photoUrl = ""; editingNumber = null
                        }
                    }
                }, enabled = name.isNotBlank() && (number.toIntOrNull() ?: 0) > 0 && players.none { it.number == number.toIntOrNull() && it.number != editingNumber },
                    modifier = Modifier.fillMaxWidth()) { Text(if (editingNumber == null) "Add player" else "Save player changes") }
                if (formNotice.isNotBlank()) Text(formNotice, style = MaterialTheme.typography.bodySmall)
                if (editingNumber != null) Button(onClick = {
                    name = ""; number = ""; grade = ""; role = ""; phone = ""; photoUrl = ""; editingNumber = null
                    formNotice = "Edit cancelled."
                }, modifier = Modifier.fillMaxWidth()) { Text("Cancel edit") }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(search, { search = it }, label = { Text("Search by name, number, grade, role or phone") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { gridMode = true }, modifier = Modifier.weight(1f)) { Text(if (gridMode) "✓ Grid view" else "Grid view") }
                    Button(onClick = { gridMode = false }, modifier = Modifier.weight(1f)) { Text(if (!gridMode) "✓ List view" else "List view") }
                }
                Button(onClick = onContinue, modifier = Modifier.fillMaxWidth()) { Text("Continue to Live Auction") }
                Text("Players: " + filtered.size + " / " + players.size, style = MaterialTheme.typography.bodySmall)
                if (filtered.isEmpty()) Text(if (players.isEmpty()) "No players added yet." else "No matching players.")
            }
        }
        if (gridMode) {
            items(filtered.chunked(2), key = { row -> row.first().number }) { rowPlayers ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowPlayers.forEach { player ->
                        Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("#" + player.number, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                                Text(player.name, fontWeight = FontWeight.SemiBold, maxLines = 2)
                                Text(if (gradesEnabled) (player.grade ?: player.role ?: "Player") else (player.role ?: "Player"), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                                Text(player.status.name, style = MaterialTheme.typography.bodySmall)
                                Button(onClick = { startEdit(player) }, modifier = Modifier.fillMaxWidth()) { Text("Edit") }
                                TextButton(onClick = { pendingDeleteNumber = player.number }, modifier = Modifier.fillMaxWidth()) { Text("Delete") }
                            }
                        }
                    }
                    if (rowPlayers.size < 2) Spacer(Modifier.weight(1f))
                }
            }
        } else {
            items(filtered, key = { it.number }) { player ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("#" + player.number + "  " + player.name, fontWeight = FontWeight.SemiBold)
                        Text((if (gradesEnabled) "Grade: " + (player.grade ?: "Not set") + " · " else "") + "Role: " + (player.role ?: "Not set"))
                        Text("Status: " + player.status.name)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { startEdit(player) }, modifier = Modifier.weight(1f)) { Text("Edit") }
                            Button(onClick = { pendingDeleteNumber = player.number }, modifier = Modifier.weight(1f)) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
    val pendingPlayer = players.firstOrNull { it.number == pendingDeleteNumber }
    if (pendingDeleteNumber != null) {
        AlertDialog(
            onDismissRequest = { pendingDeleteNumber = null },
            title = { Text("Delete player?") },
            text = { Text(if (pendingPlayer != null) "Delete #${pendingPlayer.number} ${pendingPlayer.name}? If sold or retained, team totals will be adjusted too." else "This player is no longer available.") },
            confirmButton = {
                TextButton(onClick = {
                    val numberToDelete = pendingDeleteNumber
                    if (numberToDelete != null && pendingPlayer != null) {
                        onDelete(numberToDelete)
                        if (editingNumber == numberToDelete) {
                            name = ""; number = ""; grade = ""; role = ""; phone = ""; photoUrl = ""
                            editingNumber = null
                            formNotice = "Player deleted."
                        }
                    }
                    pendingDeleteNumber = null
                }, enabled = pendingPlayer != null) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { pendingDeleteNumber = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun TeamsScreen(
    teams: List<AuctionTeam>,
    players: List<AuctionPlayer>,
    config: AuctionConfig,
    onContinue: () -> Unit,
    onAdd: (AuctionTeam) -> Unit,
    onUpdate: (String, String, String, String) -> Unit,
    onDelete: (String) -> Unit
) {
    // Colours are internal metadata only; users do not see or enter colour codes.
    val teamColors = listOf("#0646A8", "#C62828", "#2E7D32", "#6A1B9A", "#EF6C00", "#00838F", "#37474F", "#AD1457")
    var notice by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Team Setup", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Add a name and short name in each of the ${config.teamCount} team boxes. All boxes are shown below.")
        Text("Teams saved: ${teams.size} / ${config.teamCount}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        repeat(config.teamCount) { slotIndex ->
            val team = teams.getOrNull(slotIndex)
            var name by remember(team?.id) { mutableStateOf(team?.name ?: "") }
            var shortName by remember(team?.id) { mutableStateOf(team?.shortName ?: "") }
            val assigned = team?.let { t -> players.count { it.teamId == t.id && (it.status == PlayerStatus.SOLD || it.status == PlayerStatus.RETAINED) } } ?: 0
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Team ${slotIndex + 1}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = name, onValueChange = { name = it.take(40) }, label = { Text("Team name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = shortName, onValueChange = { shortName = it.take(8) }, label = { Text("Short name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    if (team != null) Text("Budget remaining: ${"%.1f".format(team.pointsRemaining)} · Players: ${team.playerCount}/${config.playersPerTeam}")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = {
                            val cleanName = name.trim()
                            val cleanShort = shortName.trim()
                            val duplicateName = teams.any { it.id != team?.id && it.name.equals(cleanName, true) }
                            val duplicateShort = teams.any { it.id != team?.id && it.shortName.equals(cleanShort, true) }
                            if (cleanName.isBlank() || cleanShort.isBlank()) notice = "Enter both a team name and short name for Team ${slotIndex + 1}."
                            else if (duplicateName || duplicateShort) notice = "Team names and short names must be unique."
                            else if (team == null) {
                                onAdd(AuctionTeam(id = "team-${java.util.UUID.randomUUID()}", name = cleanName, shortName = cleanShort, colorHex = teamColors[slotIndex % teamColors.size], startingPoints = config.startingPoints))
                                notice = "Team ${slotIndex + 1} saved."
                            } else { onUpdate(team.id, cleanName, cleanShort, team.colorHex); notice = "Team ${slotIndex + 1} updated." }
                        }, enabled = name.isNotBlank() && shortName.isNotBlank(), modifier = Modifier.weight(1f)) {
                            Text(if (team == null) "Save Team ${slotIndex + 1}" else "Update Team ${slotIndex + 1}")
                        }
                        if (team != null) OutlinedButton(onClick = {
                            if (assigned == 0 && team.pointsSpent == 0.0) { onDelete(team.id); notice = "Team ${slotIndex + 1} removed." }
                            else notice = "This team has auction activity and cannot be deleted."
                        }, enabled = assigned == 0 && team.pointsSpent == 0.0) { Text("Delete") }
                    }
                }
            }
        }
        if (notice.isNotBlank()) Text(notice, style = MaterialTheme.typography.bodySmall)
        Button(onClick = onContinue, enabled = teams.size == config.teamCount && teams.all { it.name.isNotBlank() && it.shortName.isNotBlank() }, modifier = Modifier.fillMaxWidth()) {
            Text(if (teams.size == config.teamCount) "Save Teams & Continue to Players" else "Complete all ${config.teamCount} team boxes first")
        }
    }
}

@Composable
private fun TeamDetailScreen(team: AuctionTeam, players: List<AuctionPlayer>, config: AuctionConfig, onRetain: (Int) -> String, onOpenAuction: () -> Unit) {
    val squad = players.filter { it.teamId == team.id && (it.status == PlayerStatus.SOLD || it.status == PlayerStatus.RETAINED) }
    val retained = squad.count { it.status == PlayerStatus.RETAINED }
    val maxNextBid = AuctionRules.maxNextBid(team, config)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(team.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Team record · " + team.shortName)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SummaryCard("Balance", "%.1f".format(team.pointsRemaining), Modifier.weight(1f))
            SummaryCard("Spent", "%.1f".format(team.pointsSpent), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SummaryCard("Squad", team.playerCount.toString() + "/" + config.playersPerTeam, Modifier.weight(1f))
            SummaryCard("Retained", retained.toString(), Modifier.weight(1f))
        }
        SummaryCard("Max next bid", "%.1f".format(maxNextBid), Modifier.fillMaxWidth())
        Button(onClick = onOpenAuction, modifier = Modifier.fillMaxWidth()) { Text("Open auction") }
        if (config.maxRetentions > 0) RetainCard(team, players, config, onRetain)
        Text("Squad", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        if (squad.isEmpty()) Text("No players assigned to this team yet.")
        squad.forEach { player ->
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("#" + player.number + " · " + player.name, fontWeight = FontWeight.SemiBold)
                    Text(player.status.name + " · Price " + "%.1f".format(player.price) + " · Round " + (player.auctionRound?.toString() ?: "—"))
                }
            }
        }
    }
}
private fun teamColor(hex: String): androidx.compose.ui.graphics.Color =
    runCatching { androidx.compose.ui.graphics.Color(android.graphics.Color.parseColor(hex)) }
        .getOrDefault(androidx.compose.ui.graphics.Color(0xFF0646A8))

@Composable
private fun RetainCard(team: AuctionTeam, players: List<AuctionPlayer>, config: AuctionConfig, onRetain: (Int) -> String) {
    var query by remember(team.id) { mutableStateOf("") }
    var message by remember(team.id) { mutableStateOf("") }
    val pending = players.filter { it.status == PlayerStatus.PENDING }
    val q = query.trim()
    val typedNumber = Regex("^\\d+").find(q)?.value?.toIntOrNull()
    val target = when {
        q.isBlank() -> null
        typedNumber != null -> pending.firstOrNull { it.number == typedNumber }
        else -> pending.firstOrNull { it.name.contains(q, ignoreCase = true) }
    }
    val matches = if (q.isBlank()) emptyList() else pending.filter {
        it.number.toString().startsWith(q) || it.name.contains(q, ignoreCase = true)
    }.take(5)
    val slotsLeft = (config.maxRetentions - team.retainedCount).coerceAtLeast(0)
    val blocked = slotsLeft <= 0 || team.pointsRemaining < config.retentionCost || team.playerCount >= config.playersPerTeam
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Retain Player", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = query, onValueChange = { query = it.take(40); message = "" },
                label = { Text("Search name / number") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            if (matches.isNotEmpty() && !(matches.size == 1 && q == matches[0].number.toString())) {
                matches.forEach { m ->
                    TextButton(onClick = { query = m.number.toString() }, modifier = Modifier.fillMaxWidth()) {
                        Text("#${m.number} · ${m.name}", maxLines = 1)
                    }
                }
            }
            Button(
                onClick = { if (target != null) { message = onRetain(target.number); query = "" } },
                enabled = !blocked && target != null,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (target != null) "Retain #${target.number} ${target.name}" else "Retain") }
            Text("Cost per retain: ${formatPoints(config.retentionCost)} · Slots remaining: $slotsLeft", style = MaterialTheme.typography.bodySmall)
            if (q.isNotBlank() && target == null) Text("No available (pending) player matches.", style = MaterialTheme.typography.bodySmall)
            if (message.isNotBlank()) Text(message, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun AuctionScreen(
    players: androidx.compose.runtime.snapshots.SnapshotStateList<AuctionPlayer>,
    teams: androidx.compose.runtime.snapshots.SnapshotStateList<AuctionTeam>,
    config: AuctionConfig,
    canUndo: Boolean,
    roundNumber: Int,
    saveSnapshot: () -> Unit,
    undoLastAction: () -> Unit,
    onBid: () -> Int,
    onNextRound: () -> Unit
) {
    var selectedNumber by rememberSaveable { mutableStateOf<Int?>(null) }
    var selectedTeamId by rememberSaveable { mutableStateOf<String?>(null) }
    val defaultBid = if (config.basePrice > 0.0) formatPoints(config.basePrice) else "1"
    var bidText by rememberSaveable(config.basePrice, selectedNumber) { mutableStateOf(defaultBid) }
    var notice by remember { mutableStateOf("") }
    var showAllTeams by rememberSaveable { mutableStateOf(false) }
    var showManualPlayers by rememberSaveable { mutableStateOf(false) }
    var showRoundDialog by rememberSaveable { mutableStateOf(false) }

    // Only pending players can be picked. Unsold players come back only when the next round starts (as in the HTML).
    val pending = players.filter { it.status == PlayerStatus.PENDING }
    val selectedPlayer = pending.firstOrNull { it.number == selectedNumber }
    val currentBid = bidText.toDoubleOrNull()
    val selectedTeam = teams.firstOrNull { it.id == selectedTeamId }
    val soldCount = players.count { it.status == PlayerStatus.SOLD }
    val unsoldCount = players.count { it.status == PlayerStatus.UNSOLD }
    val retainedCount = players.count { it.status == PlayerStatus.RETAINED }
    val poolTotal = players.size - retainedCount

    val canSellSelected = selectedPlayer != null && selectedTeam != null && currentBid != null &&
        AuctionRules.canSell(selectedPlayer, selectedTeam, config, currentBid)

    fun resetSelection() {
        selectedNumber = null
        selectedTeamId = null
        bidText = defaultBid
    }

    fun pickRandom() {
        if (pending.isEmpty() && unsoldCount > 0) {
            onNextRound()
            notice = "Next round started automatically."
        } else notice = ""
        val picked = players.filter { it.status == PlayerStatus.PENDING }.randomOrNull()
        if (picked != null) {
            selectedNumber = picked.number
            selectedTeamId = null
            bidText = defaultBid
        } else {
            selectedNumber = null
            notice = "No pending or unsold players left."
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            CompactAuctionStat("Round", roundNumber.toString(), Modifier.weight(1f))
            CompactAuctionStat("Pool", "${pending.size}/$poolTotal", Modifier.weight(1.2f))
            CompactAuctionStat("Sold", soldCount.toString(), Modifier.weight(1f))
            CompactAuctionStat("Unsold", unsoldCount.toString(), Modifier.weight(1f))
            if (config.maxRetentions > 0) CompactAuctionStat("Retained", retainedCount.toString(), Modifier.weight(1.1f))
        }

        // Player name and dice selector share the same row. Tap the name for the full pending list (HTML "Player list").
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFFFFE7B5)) {
                    Text("ROUND $roundNumber", modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black, color = Color(0xFF634500), maxLines = 1)
                }
                Box(Modifier.weight(1f).height(62.dp).clickable(enabled = pending.isNotEmpty()) { showManualPlayers = true }, contentAlignment = androidx.compose.ui.Alignment.Center) {
                    Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(selectedPlayer?.name ?: if (pending.isEmpty()) "No pending players" else "Select Player", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary, maxLines = 1)
                        if (selectedPlayer != null) {
                            Text(buildString {
                                append("#${selectedPlayer.number}")
                                selectedPlayer.role?.takeIf { it.isNotBlank() }?.let { append(" · ").append(it) }
                                if (config.enablePlayerGrades) selectedPlayer.grade?.takeIf { it.isNotBlank() }?.let { append(" · ").append(it) }
                            }, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        } else if (pending.isNotEmpty()) Text("Tap name to browse players", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Button(onClick = { pickRandom() }, enabled = pending.isNotEmpty() || unsoldCount > 0, modifier = Modifier.height(42.dp), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 0.dp)) {
                    Text("🎲", style = MaterialTheme.typography.titleMedium)
                }
            }
        }

        // All bid controls stay on one horizontal line: -1, PRICE, +1, +2, +5.
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFF4F7F5)), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val floor = if (config.basePrice > 0.0) config.basePrice else 1.0
                OutlinedButton(
                    onClick = { bidText = formatPoints(((bidText.toDoubleOrNull() ?: floor) - 1.0).coerceAtLeast(floor)) },
                    modifier = Modifier.weight(1f).height(34.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                ) { Text("−1", fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
                OutlinedTextField(
                    value = bidText,
                    onValueChange = { raw -> bidText = raw.filter { it.isDigit() || it == '.' }.take(3) },
                    modifier = Modifier.width(70.dp).height(48.dp),
                    singleLine = true,
                    textStyle = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black, textAlign = androidx.compose.ui.text.style.TextAlign.Center),
                    label = { Text("PRICE", style = MaterialTheme.typography.labelSmall, maxLines = 1) }
                )
                OutlinedButton(
                    onClick = { bidText = formatPoints((bidText.toDoubleOrNull() ?: floor) + 1.0) },
                    modifier = Modifier.weight(1f).height(34.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                ) { Text("+1", fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
                OutlinedButton(
                    onClick = { bidText = formatPoints((bidText.toDoubleOrNull() ?: floor) + 2.0) },
                    modifier = Modifier.weight(1f).height(34.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                ) { Text("+2", fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
                OutlinedButton(
                    onClick = { bidText = formatPoints((bidText.toDoubleOrNull() ?: floor) + 5.0) },
                    modifier = Modifier.weight(1f).height(34.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                ) { Text("+5", fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
            }
        }

        // Team grid: 4 per row, so any number of teams just adds rows (the screen scrolls). Full squads are dimmed.
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            teams.chunked(4).forEach { teamRow ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    teamRow.forEach { t ->
                        val selected = t.id == selectedTeamId
                        val full = t.playerCount >= config.playersPerTeam
                        val maxBid = AuctionRules.maxNextBid(t, config)
                        Card(
                            modifier = Modifier.weight(1f).alpha(if (full) 0.5f else 1f).clickable(enabled = !full) {
                                selectedTeamId = if (selected) null else t.id
                            },
                            colors = CardDefaults.cardColors(
                                containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                        ) {
                            Column(
                                Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
                                verticalArrangement = Arrangement.spacedBy(0.dp)
                            ) {
                                Text(
                                    t.shortName.ifBlank { t.name },
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = teamColor(t.colorHex),
                                    maxLines = 1
                                )
                                Text("${t.playerCount}/${config.playersPerTeam}", style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                Text("R ${formatPoints(t.pointsRemaining.coerceAtLeast(0.0))}", style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                Text("N ${formatPoints(maxBid)}", style = MaterialTheme.typography.labelSmall, maxLines = 1)
                            }
                        }
                    }
                    repeat((4 - teamRow.size).coerceAtLeast(0)) { Spacer(Modifier.weight(1f)) }
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Button(
                onClick = {
                    val p = selectedPlayer
                    val t = selectedTeam
                    val amount = currentBid
                    if (p != null && t != null && amount != null && AuctionRules.canSell(p, t, config, amount)) {
                        val pi = players.indexOfFirst { it.number == p.number }
                        val ti = teams.indexOfFirst { it.id == t.id }
                        if (pi >= 0 && ti >= 0) {
                            saveSnapshot()
                            val turn = onBid()
                            players[pi] = p.copy(
                                status = PlayerStatus.SOLD, teamId = t.id, price = amount,
                                auctionTurn = turn, auctionRound = roundNumber
                            )
                            teams[ti] = t.copy(pointsSpent = t.pointsSpent + amount, playerCount = t.playerCount + 1)
                            notice = "${p.name} sold to ${t.shortName} for ${formatPoints(amount)}."
                            resetSelection()
                            if (players.none { it.status == PlayerStatus.PENDING }) showRoundDialog = true
                        }
                    }
                },
                enabled = canSellSelected,
                modifier = Modifier.weight(1f).height(44.dp),
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF16783B), contentColor = Color.White,
                    disabledContainerColor = Color(0xFFB8CDBE), disabledContentColor = Color(0xFF244B34)
                )
            ) { Text("SOLD", fontWeight = FontWeight.Bold) }

            OutlinedButton(
                onClick = {
                    val p = selectedPlayer
                    val pi = players.indexOfFirst { it.number == p?.number }
                    if (p != null && pi >= 0) {
                        saveSnapshot()
                        val turn = onBid()
                        players[pi] = p.copy(status = PlayerStatus.UNSOLD, teamId = null, price = 0.0, auctionTurn = turn, auctionRound = roundNumber)
                        notice = "${p.name} marked unsold."
                        resetSelection()
                        if (players.none { it.status == PlayerStatus.PENDING }) showRoundDialog = true
                    }
                },
                enabled = selectedPlayer != null,
                modifier = Modifier.weight(1f).height(44.dp),
                colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
                    containerColor = Color(0xFFC62828), contentColor = Color.White,
                    disabledContainerColor = Color(0xFFF0C9C9), disabledContentColor = Color(0xFF7A2525)
                )
            ) { Text("UNSOLD", fontWeight = FontWeight.Bold) }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            OutlinedButton(
                onClick = {
                    undoLastAction()
                    resetSelection()
                    showRoundDialog = false
                    notice = "Last action undone."
                },
                enabled = canUndo,
                modifier = Modifier.weight(1f).height(42.dp)
            ) { Text("↩ Undo") }
            OutlinedButton(
                onClick = { showAllTeams = true },
                modifier = Modifier.weight(1f).height(42.dp)
            ) { Text("All Teams") }
        }

        if (notice.isNotBlank()) {
            Text(notice, style = MaterialTheme.typography.labelMedium, maxLines = 2)
        }

        // History of the latest auction actions (newest first), like the HTML history list.
        val historyItems = players
            .filter { (it.status == PlayerStatus.SOLD || it.status == PlayerStatus.UNSOLD) && it.auctionTurn != null }
            .sortedByDescending { it.auctionTurn }
            .take(20)
        Text("Auction event history", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        if (historyItems.isEmpty()) Text("No auction events yet. Sold/Unsold actions will appear here in order.", style = MaterialTheme.typography.bodySmall)
        historyItems.forEach { p ->
            val team = teams.firstOrNull { it.id == p.teamId }
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("${p.auctionTurn}", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Column(Modifier.weight(1f)) {
                        Text("#${p.number} ${p.name}", fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Text(
                            "Round ${p.auctionRound ?: 1} · " + (if (p.status == PlayerStatus.UNSOLD) "Unsold" else (team?.shortName ?: "—")),
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                    Text(if (p.status == PlayerStatus.UNSOLD) "Unsold" else formatPoints(p.price), fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showRoundDialog) {
        val unsoldNow = players.count { it.status == PlayerStatus.UNSOLD }
        if (unsoldNow > 0) {
            AlertDialog(
                onDismissRequest = { showRoundDialog = false },
                title = { Text("Round $roundNumber complete") },
                text = { Text("$unsoldNow player(s) went unsold. Start the next round with them?") },
                confirmButton = {
                    TextButton(onClick = {
                        showRoundDialog = false
                        onNextRound()
                        notice = "Next round started."
                    }) { Text("Start Next Round") }
                },
                dismissButton = { TextButton(onClick = { showRoundDialog = false }) { Text("Later") } }
            )
        } else {
            AlertDialog(
                onDismissRequest = { showRoundDialog = false },
                title = { Text("Auction complete") },
                text = { Text("No pending or unsold players remain.") },
                confirmButton = { TextButton(onClick = { showRoundDialog = false }) { Text("Finish") } }
            )
        }
    }

    if (showManualPlayers) {
        AlertDialog(
            onDismissRequest = { showManualPlayers = false },
            title = { Text("Choose Player") },
            text = {
                Column(
                    Modifier.height(360.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    pending.forEach { p ->
                        TextButton(
                            onClick = {
                                selectedNumber = p.number
                                selectedTeamId = null
                                bidText = defaultBid
                                notice = ""
                                showManualPlayers = false
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("#${p.number} · ${p.name}") }
                    }
                    if (pending.isEmpty()) Text("No players remaining.")
                }
            },
            confirmButton = { TextButton(onClick = { showManualPlayers = false }) { Text("Close") } }
        )
    }

    if (showAllTeams) {
        AlertDialog(
            onDismissRequest = { showAllTeams = false },
            title = { Text("All Teams") },
            text = {
                Column(
                    Modifier.height(360.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    teams.forEach { t ->
                        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
                            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(t.name, fontWeight = FontWeight.Bold)
                                Text("Squad ${t.playerCount}/${config.playersPerTeam} · Retained ${t.retainedCount}")
                                Text("Remaining Points: ${formatPoints(t.pointsRemaining.coerceAtLeast(0.0))}")
                                Text("Next Bid Max: ${formatPoints(AuctionRules.maxNextBid(t, config))}")
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showAllTeams = false }) { Text("Close") } }
        )
    }
}

@Composable
private fun CompactAuctionStat(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 5.dp),
            verticalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1)
            Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

private fun formatPoints(value: Double): String =
    if (value.isFinite() && value % 1.0 == 0.0) value.toLong().toString()
    else if (value.isFinite()) "%.1f".format(value) else "0"

@Composable
private fun SettingsScreen(config: AuctionConfig, onSave: (AuctionConfig) -> Unit) {
    var basePrice by remember(config.basePrice) { mutableStateOf(config.basePrice.toString()) }
    var budget by remember(config.startingPoints) { mutableStateOf(config.startingPoints.toString()) }
    var squadLimit by remember(config.playersPerTeam) { mutableStateOf(config.playersPerTeam.toString()) }
    var retentionLimit by remember(config.maxRetentions) { mutableStateOf(config.maxRetentions.toString()) }
    var retentionCost by remember(config.retentionCost) { mutableStateOf(config.retentionCost.toString()) }
    var teamCount by remember(config.teamCount) { mutableStateOf(config.teamCount.toString()) }
    var gradesEnabled by remember(config.enablePlayerGrades) { mutableStateOf(config.enablePlayerGrades) }
    val base = basePrice.toDoubleOrNull()
    val points = budget.toDoubleOrNull()
    val squad = squadLimit.toIntOrNull()
    val retention = retentionLimit.toIntOrNull()
    val cost = retentionCost.toDoubleOrNull()
    val count = teamCount.toIntOrNull()
    val valid = base != null && base >= 0 && points != null && points > 0 &&
        squad != null && squad > 0 && retention != null && retention >= 0 &&
        cost != null && cost >= 0 && count != null && count > 0
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("League settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Set the rules used by the auction.")
        Text("Common Base Price is reserved for each unfilled squad slot. Set it to 0 to allow a maximum bid of 100 points.", style = MaterialTheme.typography.bodySmall)
        Text("AUCTION CONFIGURATION", modifier = Modifier.fillMaxWidth().background(Color(0xFFDCEBE0), RoundedCornerShape(10.dp)).padding(horizontal = 12.dp, vertical = 10.dp), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
        OutlinedTextField(basePrice, { basePrice = it.filter { ch -> ch.isDigit() || ch == '.' }.take(10) }, label = { Text("Common Base Price") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(budget, { budget = it.filter { ch -> ch.isDigit() || ch == '.' }.take(10) }, label = { Text("Team Budget") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(squadLimit, { squadLimit = it.filter(Char::isDigit).take(3) }, label = { Text("Squad limit per team") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(teamCount, { teamCount = it.filter(Char::isDigit).take(2) }, label = { Text("Number of teams (planning setting)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(retentionLimit, { retentionLimit = it.filter(Char::isDigit).take(2) }, label = { Text("Maximum retentions per team") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(retentionCost, { retentionCost = it.filter { ch -> ch.isDigit() || ch == '.' }.take(10) }, label = { Text("Retention cost") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Enable Player Grades", style = MaterialTheme.typography.bodyLarge)
            TextButton(onClick = { gradesEnabled = !gradesEnabled }) { Text(if (gradesEnabled) "Yes ✓" else "No") }
        }
        Button(onClick = {
            if (valid) onSave(AuctionConfig(
                playersPerTeam = squad!!, basePrice = base!!, startingPoints = points!!,
                maxRetentions = retention!!, retentionCost = cost!!, teamCount = count!!,
                enablePlayerGrades = gradesEnabled
            ))
        }, enabled = valid, modifier = Modifier.fillMaxWidth()) { Text("Save league settings") }
        Text("Changes to Team Budget apply to teams that have not spent points or selected players. Existing auction results are kept.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun AppToolsScreen(players: List<AuctionPlayer>, teams: List<AuctionTeam>, config: AuctionConfig) {
    val context = LocalContext.current
    val packageInfo = remember {
        runCatching {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageInfo(context.packageName, 0)
        }.getOrNull()
    }
    val currentVersionName = packageInfo?.versionName ?: "Unknown"
    val currentVersionCode = packageInfo?.let {
        if (android.os.Build.VERSION.SDK_INT >= 28) it.longVersionCode else {
            @Suppress("DEPRECATION")
            it.versionCode.toLong()
        }
    } ?: 0L
    var showPrivacy by remember { mutableStateOf(false) }
    var checkingUpdate by remember { mutableStateOf(false) }
    var updateMessage by remember { mutableStateOf<String?>(null) }
    var availableApkUrl by remember { mutableStateOf<String?>(null) }
    var availableVersion by remember { mutableStateOf<String?>(null) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val manifestUrl = "https://raw.githubusercontent.com/amarjeetmaan3/Ajupdates/main/apps/aj-auction.json"
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("App information", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Current app version: ${currentVersionName} (code ${currentVersionCode})")
        Button(onClick = { showPrivacy = true }, modifier = Modifier.fillMaxWidth()) { Text("Privacy policy") }
        Button(enabled = !checkingUpdate, onClick = {
            checkingUpdate = true
            updateMessage = null
            availableApkUrl = null
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val connection = (URL(manifestUrl + "?t=" + System.currentTimeMillis()).openConnection() as HttpURLConnection).apply {
                            connectTimeout = 10000
                            readTimeout = 10000
                            requestMethod = "GET"
                        }
                        try {
                            if (connection.responseCode !in 200..299) error("Update server returned HTTP " + connection.responseCode)
                            val data = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
                            val code = data.optLong("versionCode", 0L)
                            val version = data.optString("latestVersion", "")
                            val url = data.optString("apkUrl", "")
                            if (code <= 0L || version.isBlank() || !url.startsWith("https://")) error("Update information is incomplete")
                            Triple(code, version, url)
                        } finally { connection.disconnect() }
                    }
                }
                checkingUpdate = false
                result.onSuccess { (code, version, url) ->
                    if (code > currentVersionCode) {
                        availableVersion = version
                        availableApkUrl = url
                        updateMessage = "Version " + version + " is available."
                    } else updateMessage = "You are using the latest version (" + currentVersionName + ")."
                }.onFailure { updateMessage = "Could not check updates: " + (it.message ?: "network error") }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text(if (checkingUpdate) "Checking updates…" else "Check updates") }
        updateMessage?.let { Text(it) }
        availableApkUrl?.let { apkUrl ->
            Button(onClick = {
                runCatching {
                    val request = DownloadManager.Request(Uri.parse(apkUrl))
                        .setTitle("AJ Auction update " + (availableVersion ?: ""))
                        .setDescription("Downloading APK update")
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "AJ-Auction-" + (availableVersion ?: "update") + ".apk")
                        .setMimeType("application/vnd.android.package-archive")
                    val manager = context.getSystemService(android.content.Context.DOWNLOAD_SERVICE) as DownloadManager
                    manager.enqueue(request)
                    updateMessage = "Download started. Open the download notification when it finishes to install."
                }.onFailure { updateMessage = "Could not start download: " + (it.message ?: "download error") }
            }, modifier = Modifier.fillMaxWidth()) { Text("Download update") }
        }
        Text("Auction data stays saved locally on this device.")
        if (showPrivacy) {
            AlertDialog(
                onDismissRequest = { showPrivacy = false },
                title = { Text("AJ Auction — Privacy Policy") },
                text = {
                    Column(Modifier.height(420.dp).verticalScroll(rememberScrollState())) {
                        Text(
                            "Last updated: October 20, 2026\n\n" +
                            "AJ Auction is an offline-first tool for managing an in-person player auction. " +
                            "Team names, player details, league settings and auction results are stored locally on this device. " +
                            "The app does not currently require an account and does not send this local auction data to our servers.\n\n" +
                            "" +
                            "Check updates reads the public Ajupdates version manifest. If an update is available, you can download the APK directly to this Android device.\n\n" +
                            "The app does not currently use location, contacts, microphone or camera permissions. Avoid including personal or sensitive information in player records or shared reports unless needed for your auction.\n\n" +
                            "This policy describes the current app behavior and may be updated as features change. For privacy questions, contact the app publisher through github.com/amarjeetmaan3/Aj-auction."
                        )
                    }
                },
                confirmButton = { TextButton(onClick = { showPrivacy = false }) { Text("Close") } }
            )
        }
    }
}

@Composable
private fun SoldScreen(players: List<AuctionPlayer>, teams: List<AuctionTeam>) {
    var filter by remember { mutableStateOf("ALL") }
    val visiblePlayers = when (filter) {
        "ALL" -> players.filter { it.status == PlayerStatus.SOLD || it.status == PlayerStatus.UNSOLD || it.status == PlayerStatus.RETAINED }
        "Sold" -> players.filter { it.status == PlayerStatus.SOLD }
        "Unsold" -> players.filter { it.status == PlayerStatus.UNSOLD }
        else -> players.filter { it.status == PlayerStatus.RETAINED }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf("ALL", "Sold", "Unsold", "Retained").forEach { option ->
                val active = filter == option
                val statusColor = when (option) {
                    "Sold" -> Color(0xFF16803D)
                    "Unsold" -> Color(0xFFC62828)
                    "ALL" -> Color(0xFF07543D)
                    else -> Color(0xFF9A6A00)
                }
                Button(
                    onClick = { filter = option },
                    modifier = Modifier.weight(1f).height(38.dp),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = if (active) statusColor else statusColor.copy(alpha = 0.10f),
                        contentColor = if (active) Color.White else statusColor
                    ),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 2.dp, vertical = 0.dp)
                ) { Text(option, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1) }
            }
        }
        if (visiblePlayers.isEmpty()) {
            Text("No ${filter.lowercase()} players yet.")
        } else {
            visiblePlayers.sortedWith(compareBy<AuctionPlayer> { it.auctionTurn ?: Int.MAX_VALUE }.thenBy { it.number }).forEach { player ->
                val team = teams.firstOrNull { it.id == player.teamId }
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(Modifier.fillMaxWidth().background(
                        when (player.status) {
                            PlayerStatus.SOLD -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.45f)
                            PlayerStatus.RETAINED -> MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f)
                            else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                        }
                    ).padding(10.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Surface(shape = androidx.compose.foundation.shape.CircleShape, color = MaterialTheme.colorScheme.secondaryContainer) {
                            Box(Modifier.padding(8.dp), contentAlignment = androidx.compose.ui.Alignment.Center) {
                                Text(player.number.toString(), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                        }
                        val statusColor = when (player.status) {
                            PlayerStatus.SOLD -> Color(0xFF16803D)
                            PlayerStatus.UNSOLD -> Color(0xFFC62828)
                            PlayerStatus.RETAINED -> Color(0xFF9A6A00)
                            else -> MaterialTheme.colorScheme.onSurface
                        }
                        Column(Modifier.weight(1f).padding(start = 10.dp)) {
                            Text(player.name, fontWeight = FontWeight.SemiBold, maxLines = 1, color = statusColor)
                            Text(
                                (team?.name ?: if (player.status == PlayerStatus.UNSOLD) "UNSOLD" else "No team") +
                                    " · Round " + (player.auctionRound?.toString() ?: "—") +
                                    (player.auctionTurn?.let { " · Bid #$it" } ?: ""),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (player.status == PlayerStatus.UNSOLD) Color(0xFFC62828) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(if (player.status == PlayerStatus.UNSOLD) "—" else formatPoints(player.price),
                            style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun TeamStatusScreen(
    teams: List<AuctionTeam>,
    players: List<AuctionPlayer>,
    config: AuctionConfig,
    onTeamClick: (AuctionTeam) -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (teams.isEmpty()) {
            Text("No teams added yet. Open Teams to add your teams.")
        } else {
            teams.chunked(4).forEach { teamRow ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    teamRow.forEach { team ->
                        val squadCount = players.count { it.teamId == team.id && it.status in listOf(PlayerStatus.SOLD, PlayerStatus.RETAINED) }
                        Card(
                            Modifier.weight(1f).clickable { onTeamClick(team) },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(
                                Modifier.fillMaxWidth().padding(horizontal = 5.dp, vertical = 7.dp),
                                horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Surface(shape = RoundedCornerShape(8.dp), color = teamColor(team.colorHex)) {
                                    Box(Modifier.padding(horizontal = 7.dp, vertical = 5.dp), contentAlignment = androidx.compose.ui.Alignment.Center) {
                                        Text(team.shortName.take(3).uppercase(), color = Color.White, fontWeight = FontWeight.Black, fontSize = 11.sp, maxLines = 1)
                                    }
                                }
                                Text(team.name, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, maxLines = 2, minLines = 2, color = MaterialTheme.colorScheme.onSurface, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                Text("$squadCount/${config.playersPerTeam}", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Box(Modifier.fillMaxWidth().height(4.dp).background(Color(0xFFDCE6DD), RoundedCornerShape(50))) {
                                    Box(Modifier.fillMaxWidth((squadCount.toFloat() / config.playersPerTeam.coerceAtLeast(1)).coerceIn(0f, 1f)).height(4.dp).background(teamColor(team.colorHex), RoundedCornerShape(50)))
                                }
                                Text(formatPoints(team.pointsRemaining.coerceAtLeast(0.0)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, maxLines = 1)
                            }
                        }
                    }
                    repeat((4 - teamRow.size).coerceAtLeast(0)) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

private data class StoredAuctionData(
    val players: List<AuctionPlayer>,
    val teams: List<AuctionTeam>,
    val config: AuctionConfig,
    val bidCounter: Int = 0,
    val retentionCounter: Int = 0,
    val roundNumber: Int = 1
)

private object AuctionLocalStore {
    private const val PREFS = "aj_auction_local_data"
    private const val LEGACY_KEY_DATA = "auction_state"

    fun deleteLeagueData(context: android.content.Context, leagueId: String) {
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).edit()
            .remove("auction_state_" + leagueId)
            .remove("auction_history_" + leagueId)
            .apply()
    }

    fun save(context: android.content.Context, leagueId: String, players: List<AuctionPlayer>, teams: List<AuctionTeam>, config: AuctionConfig, bidCounter: Int, retentionCounter: Int, roundNumber: Int) {
        val root = JSONObject()
        root.put("config", JSONObject().apply {
            put("playersPerTeam", config.playersPerTeam)
            put("basePrice", config.basePrice)
            put("startingPoints", config.startingPoints)
            put("maxRetentions", config.maxRetentions)
            put("retentionCost", config.retentionCost)
            put("teamCount", config.teamCount)
            put("enablePlayerGrades", config.enablePlayerGrades)
        })
        root.put("players", JSONArray().apply {
            players.forEach { p -> put(JSONObject().apply {
                put("number", p.number); put("name", p.name)
                put("grade", p.grade ?: JSONObject.NULL); put("role", p.role ?: JSONObject.NULL)
                put("phone", p.phone ?: JSONObject.NULL); put("photoUrl", p.photoUrl ?: JSONObject.NULL)
                put("status", p.status.name); put("teamId", p.teamId ?: JSONObject.NULL)
                put("price", p.price); put("auctionTurn", p.auctionTurn ?: JSONObject.NULL)
                put("auctionRound", p.auctionRound ?: JSONObject.NULL)
            }) }
        })
        root.put("bidCounter", bidCounter)
        root.put("retentionCounter", retentionCounter)
        root.put("roundNumber", roundNumber.coerceAtLeast(1))
        root.put("teams", JSONArray().apply {
            teams.forEach { t -> put(JSONObject().apply {
                put("id", t.id); put("name", t.name); put("shortName", t.shortName)
                put("colorHex", t.colorHex); put("startingPoints", t.startingPoints)
                put("pointsSpent", t.pointsSpent); put("playerCount", t.playerCount)
                put("retainedCount", t.retainedCount)
            }) }
        })
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
            .edit().putString("auction_state_" + leagueId, root.toString()).apply()
    }

    fun createBackup(leagueName: String, players: List<AuctionPlayer>, teams: List<AuctionTeam>, config: AuctionConfig, bidCounter: Int, retentionCounter: Int, roundNumber: Int): String {
        val root = JSONObject()
        root.put("format", "aj-auction-backup-v1")
        root.put("leagueName", leagueName)
        root.put("config", JSONObject().apply {
            put("playersPerTeam", config.playersPerTeam); put("basePrice", config.basePrice)
            put("startingPoints", config.startingPoints); put("maxRetentions", config.maxRetentions)
            put("retentionCost", config.retentionCost); put("teamCount", config.teamCount)
            put("enablePlayerGrades", config.enablePlayerGrades)
        })
        root.put("players", JSONArray().apply { players.forEach { p -> put(JSONObject().apply {
            put("number", p.number); put("name", p.name); put("grade", p.grade ?: JSONObject.NULL); put("role", p.role ?: JSONObject.NULL)
            put("phone", p.phone ?: JSONObject.NULL); put("photoUrl", p.photoUrl ?: JSONObject.NULL); put("status", p.status.name)
            put("teamId", p.teamId ?: JSONObject.NULL); put("price", p.price); put("auctionTurn", p.auctionTurn ?: JSONObject.NULL)
            put("auctionRound", p.auctionRound ?: JSONObject.NULL)
        }) } })
        root.put("teams", JSONArray().apply { teams.forEach { t -> put(JSONObject().apply {
            put("id", t.id); put("name", t.name); put("shortName", t.shortName); put("colorHex", t.colorHex)
            put("startingPoints", t.startingPoints); put("pointsSpent", t.pointsSpent); put("playerCount", t.playerCount); put("retainedCount", t.retainedCount)
        }) } })
        root.put("bidCounter", bidCounter); root.put("retentionCounter", retentionCounter); root.put("roundNumber", roundNumber)
        return root.toString(2)
    }

    fun parseBackup(raw: String): StoredAuctionData? = runCatching {
        val root = JSONObject(raw)
        if (root.optString("format") != "aj-auction-backup-v1") return null
        val c = root.optJSONObject("config") ?: JSONObject()
        val config = AuctionConfig(c.optInt("playersPerTeam", 11), c.optDouble("basePrice", 2.0), c.optDouble("startingPoints", 100.0),
            c.optInt("maxRetentions", 2), c.optDouble("retentionCost", 10.0), c.optInt("teamCount", 4), c.optBoolean("enablePlayerGrades", false))
        val players = mutableListOf<AuctionPlayer>()
        val pa = root.optJSONArray("players") ?: return null
        for (i in 0 until pa.length()) {
            val p = pa.optJSONObject(i) ?: continue
            players.add(AuctionPlayer(p.optInt("number"), p.optString("name"),
                if (p.isNull("grade")) null else p.optString("grade"), if (p.isNull("role")) null else p.optString("role"),
                if (p.isNull("phone")) null else p.optString("phone"), if (p.isNull("photoUrl")) null else p.optString("photoUrl"),
                runCatching { PlayerStatus.valueOf(p.optString("status", "PENDING")) }.getOrDefault(PlayerStatus.PENDING),
                if (p.isNull("teamId")) null else p.optString("teamId"), p.optDouble("price", 0.0),
                if (p.isNull("auctionTurn")) null else p.optInt("auctionTurn"),
                if (p.isNull("auctionRound")) null else p.optInt("auctionRound")))
        }
        val teams = mutableListOf<AuctionTeam>()
        val ta = root.optJSONArray("teams") ?: return null
        for (i in 0 until ta.length()) {
            val t = ta.optJSONObject(i) ?: continue
            teams.add(AuctionTeam(t.optString("id"), t.optString("name"), t.optString("shortName"), t.optString("colorHex", "#0646A8"),
                t.optDouble("startingPoints", config.startingPoints), t.optDouble("pointsSpent", 0.0), t.optInt("playerCount", 0), t.optInt("retainedCount", 0)))
        }
        StoredAuctionData(players, teams, config, root.optInt("bidCounter", 0).coerceAtLeast(0),
            root.optInt("retentionCounter", 0).coerceAtLeast(0), root.optInt("roundNumber", 1).coerceAtLeast(1))
    }.getOrNull()

    fun saveHistory(context: android.content.Context, leagueId: String, history: List<AuctionSnapshot>) {
        val array = JSONArray()
        history.takeLast(50).forEach { snap ->
            val state = JSONObject()
            state.put("bidCounter", snap.bidCounter); state.put("retentionCounter", snap.retentionCounter); state.put("roundNumber", snap.roundNumber)
            state.put("players", JSONArray().apply { snap.players.forEach { p -> put(JSONObject().apply {
                put("number", p.number); put("name", p.name); put("grade", p.grade ?: JSONObject.NULL); put("role", p.role ?: JSONObject.NULL)
                put("phone", p.phone ?: JSONObject.NULL); put("photoUrl", p.photoUrl ?: JSONObject.NULL); put("status", p.status.name)
                put("teamId", p.teamId ?: JSONObject.NULL); put("price", p.price); put("auctionTurn", p.auctionTurn ?: JSONObject.NULL); put("auctionRound", p.auctionRound ?: JSONObject.NULL)
            }) } })
            state.put("teams", JSONArray().apply { snap.teams.forEach { t -> put(JSONObject().apply {
                put("id", t.id); put("name", t.name); put("shortName", t.shortName); put("colorHex", t.colorHex); put("startingPoints", t.startingPoints)
                put("pointsSpent", t.pointsSpent); put("playerCount", t.playerCount); put("retainedCount", t.retainedCount)
            }) } })
            array.put(state)
        }
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).edit().putString("auction_history_" + leagueId, array.toString()).apply()
    }

    fun loadHistory(context: android.content.Context, leagueId: String): List<AuctionSnapshot> {
        return runCatching {
            val raw = context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).getString("auction_history_" + leagueId, null) ?: return emptyList()
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { index ->
                val state = array.optJSONObject(index) ?: return@mapNotNull null
                val ps = mutableListOf<AuctionPlayer>(); val pa = state.optJSONArray("players") ?: JSONArray()
                for (i in 0 until pa.length()) { val p = pa.optJSONObject(i) ?: continue; ps.add(AuctionPlayer(
                    number = p.optInt("number"), name = p.optString("name"), grade = if (p.isNull("grade")) null else p.optString("grade"),
                    role = if (p.isNull("role")) null else p.optString("role"), phone = if (p.isNull("phone")) null else p.optString("phone"),
                    photoUrl = if (p.isNull("photoUrl")) null else p.optString("photoUrl"), status = runCatching { PlayerStatus.valueOf(p.optString("status", "PENDING")) }.getOrDefault(PlayerStatus.PENDING),
                    teamId = if (p.isNull("teamId")) null else p.optString("teamId"), price = p.optDouble("price", 0.0),
                    auctionTurn = if (p.isNull("auctionTurn")) null else p.optInt("auctionTurn"), auctionRound = if (p.isNull("auctionRound")) null else p.optInt("auctionRound")
                )) }
                val ts = mutableListOf<AuctionTeam>(); val ta = state.optJSONArray("teams") ?: JSONArray()
                for (i in 0 until ta.length()) { val t = ta.optJSONObject(i) ?: continue; ts.add(AuctionTeam(
                    id = t.optString("id"), name = t.optString("name"), shortName = t.optString("shortName"), colorHex = t.optString("colorHex", "#0646A8"),
                    startingPoints = t.optDouble("startingPoints", 100.0), pointsSpent = t.optDouble("pointsSpent", 0.0),
                    playerCount = t.optInt("playerCount", 0), retainedCount = t.optInt("retainedCount", 0)
                )) }
                AuctionSnapshot(ps, ts, state.optInt("bidCounter", 0), state.optInt("retentionCounter", 0), state.optInt("roundNumber", 1).coerceAtLeast(1))
            }.takeLast(50)
        }.getOrDefault(emptyList())
    }

    fun load(context: android.content.Context, leagueId: String): StoredAuctionData {
        val fallback = StoredAuctionData(emptyList(), emptyList(), AuctionConfig())
        return try {
            val prefs = context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
            val raw = (prefs.getString("auction_state_" + leagueId, null)
                ?: if (leagueId == "legacy-default") prefs.getString(LEGACY_KEY_DATA, null) else null)
                ?: return fallback
            val root = JSONObject(raw)
            val c = root.optJSONObject("config") ?: JSONObject()
            val config = AuctionConfig(
                playersPerTeam = c.optInt("playersPerTeam", 11),
                basePrice = c.optDouble("basePrice", 2.0),
                startingPoints = c.optDouble("startingPoints", 100.0),
                maxRetentions = c.optInt("maxRetentions", 2),
                retentionCost = c.optDouble("retentionCost", 10.0),
                teamCount = c.optInt("teamCount", 4),
                enablePlayerGrades = c.optBoolean("enablePlayerGrades", false)
            )
            val players = mutableListOf<AuctionPlayer>()
            val playerArray = root.optJSONArray("players") ?: JSONArray()
            for (i in 0 until playerArray.length()) {
                val p = playerArray.optJSONObject(i) ?: continue
                players.add(AuctionPlayer(
                    number = p.optInt("number"), name = p.optString("name"),
                    grade = p.optNullableString("grade"), role = p.optNullableString("role"),
                    phone = p.optNullableString("phone"), photoUrl = p.optNullableString("photoUrl"),
                    status = runCatching { PlayerStatus.valueOf(p.optString("status", "PENDING")) }.getOrDefault(PlayerStatus.PENDING),
                    teamId = p.optNullableString("teamId"), price = p.optDouble("price", 0.0),
                    auctionTurn = if (p.isNull("auctionTurn")) null else p.optInt("auctionTurn"),
                    auctionRound = if (p.isNull("auctionRound")) null else p.optInt("auctionRound")
                ))
            }
            val teams = mutableListOf<AuctionTeam>()
            val teamArray = root.optJSONArray("teams") ?: JSONArray()
            for (i in 0 until teamArray.length()) {
                val t = teamArray.optJSONObject(i) ?: continue
                teams.add(AuctionTeam(
                    id = t.optString("id"), name = t.optString("name"),
                    shortName = t.optString("shortName"), colorHex = t.optString("colorHex", "#0646A8"),
                    startingPoints = t.optDouble("startingPoints", config.startingPoints),
                    pointsSpent = t.optDouble("pointsSpent", 0.0),
                    playerCount = t.optInt("playerCount", 0), retainedCount = t.optInt("retainedCount", 0)
                ))
            }
            StoredAuctionData(players, teams, config, root.optInt("bidCounter", 0).coerceAtLeast(0), root.optInt("retentionCounter", 0).coerceAtLeast(0), root.optInt("roundNumber", 1).coerceAtLeast(1))
        } catch (_: Exception) { fallback }
    }

    private fun JSONObject.optNullableString(key: String): String? =
        if (isNull(key)) null else optString(key).takeIf { it.isNotBlank() }
}
