# Project rules — must follow

1. Native Android only; do not use WebView.
2. Only discuss and modify this Auction App and its repository for this task.
3. Admin-only login. Remove Team Owner login, online bidding and Viewer mode.
4. Keep every other existing feature unless the user explicitly approves a change.
5. Keep the current UI behavior and avoid unrelated redesigns.
6. Firebase data storage/sync can remain; never wipe or reset production data as part of setup.
7. Before APK/release work, verify the exact permanent application ID, debug/release signing setup and keystore. Do not guess these values.
8. Keep the same permanent release keystore for future updates and increment `versionCode`; test updates over the existing install without uninstalling.
9. Never upload keystores, passwords, service-account files or secrets to GitHub.
10. Build and test each stage; do not claim a feature works until tested.

## Required pre-build check
The current `Aj-auction` GitHub repository was empty when initialization began, and the supplied HTML reference does not establish the Android `applicationId` or a release keystore. Confirm these before finalizing the Android app module and signing configuration.
