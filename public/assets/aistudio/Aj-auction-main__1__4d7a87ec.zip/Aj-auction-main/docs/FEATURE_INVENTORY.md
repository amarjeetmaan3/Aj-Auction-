# Auction App — Feature Inventory

This inventory is based on the supplied `index (2).html` reference and the user's explicit decisions. The HTML is a behavior reference only; the Android implementation must be native Kotlin/Jetpack Compose.

## Keep
- League creation and league settings.
- Team setup, team names, squad limits, starting budget/points, retention limits and retention costs.
- Player management, player grades (when enabled), player list and player details/images.
- Admin-controlled, in-person live auction.
- Bid increments/history and sale order.
- Mark players sold or unsold; revisit unsold players in later rounds.
- Retain players and deduct retention cost from team budget.
- Team budget/spend/count tracking.
- Sold/unsold lists and team squad views.
- Undo last auction/retention action using history snapshots.
- Reset auction, with clear confirmation safeguards.
- League backup and restore.
- PDF reports (jsPDF/jsPDF-AutoTable are used by the HTML reference).
- Player result cards and image sharing.
- Telegram sharing controls.
- Light and dark themes.
- Firebase-backed persistence/sync, subject to validating the existing Firebase data model and security rules.

- **Live Auction Overlay for YouTube/live production**: a separate, browser-based transparent overlay that can be added as a browser source in streaming software or opened as a standalone page for screen sharing. It must display the current player, team/bid amount, sold/unsold state, team budgets/roster and optional recent bid ticker; update as the native admin app changes the auction. Overlay is display-only: no bid controls, no owner/viewer login, and no remote bidding. Provide configurable compact layouts, transparent background, hide/show sections, and a public/private access token so an exposed overlay URL does not grant auction-control access. Use the same auction state and Firebase data model only after schema/rules are audited; never reuse credentials from another project or reset existing data. Add a dedicated overlay preview/settings area in the native app, with copy/open overlay URL actions after the hosting and access model are implemented.

## Remove
- Team Owner login/password screens.
- Online/remote bidding by team owners.
- Viewer Mode / non-admin viewing mode.

## Access model
- Admin-only sign-in and admin-controlled auction actions.
- Firebase data sync is a persistence feature; it must not reintroduce remote bidding or owner accounts.

## Implementation and release guardrails
- Do not build this as a WebView.
- Do not reset or delete Firebase data during setup.
- Do not commit Firebase credentials, keystores, signing passwords, or service-account files.
- Do not guess the permanent Android application ID or release signing material. Confirm the chosen values before producing distributable APKs.
- Increment versionCode for subsequent APK updates and verify update/signing behavior before distribution.
- Preserve existing behavior and avoid unrelated redesigns.

## Not yet verified
- Exact Firebase paths/data schema and rules to be used by the native app.
- Final Android application ID / namespace.
- Release keystore ownership and signing configuration.
- Native feature parity and successful Android build/test.
