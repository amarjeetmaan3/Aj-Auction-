# AJ Auction Privacy Policy

Last updated: October 20, 2026

AJ Auction is an offline-first tool for managing an in-person player auction.

## Data stored on your device
Team names, player details, league settings, and auction results are stored locally on your device. The current app does not require an account and does not send this locally stored auction data to our servers.

## Update checks and downloads
When you use **Check updates**, the app connects to GitHub to read publicly hosted version information. If a newer version is available, you can choose **Download new version**, which opens the APK download link. GitHub may process connection data under its own privacy policy.

## Permissions
The current app uses internet access for update checks. It does not request location, contacts, microphone, or camera permissions.

## Personal information
Avoid entering personal or sensitive information in player records unless it is needed for your auction.

## Changes and contact
This policy describes current app behavior and may change as features evolve. For questions, visit the project repository: https://github.com/amarjeetmaan3/Aj-auction
