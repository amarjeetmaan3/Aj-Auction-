# AJ Auction — Native Android

A native Android auction-management app built with Kotlin and Jetpack Compose. This project is not a WebView wrapper.

## Product rules
- Admin-only sign-in; auction is controlled in person by the Admin.
- No Team Owner login, online bidding, or Viewer mode.
- Preserve all other existing auction features from the supplied HTML reference.
- Firebase may remain as the data persistence/sync backend; Firebase sync does not mean online bidding.
- Do not delete or reset existing Firebase data during setup.
- Do not change unrelated UI or features without approval.

## Android release safety
- Confirm the permanent `applicationId`, signing configuration, and keystore before creating release APKs.
- Do not guess or change the permanent package/application ID once chosen.
- Keep the same release keystore for all future updates; increment `versionCode` for each update.
- Never commit keystore files, passwords, service-account files, or other secrets to GitHub.
- Verify signing compatibility before distributing an APK; do not require uninstall/reinstall for routine updates.

## Current status
This repository is being initialized. The original HTML file is a behavior/feature reference only; the Android app must be implemented natively. The exact permanent `applicationId` and release signing material have not yet been verified, so no release signing configuration is set yet.
