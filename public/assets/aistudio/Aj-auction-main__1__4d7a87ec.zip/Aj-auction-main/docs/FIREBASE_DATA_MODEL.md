# Firebase Data Model Audit (from supplied HTML)

## Project reference
The supplied HTML config points to Firebase project `auction-pro-live` and Realtime Database region `asia-southeast1`. This records what the source references; it does not prove that the project is accessible, its rules are secure, or that native Android credentials are configured.

## Observed Realtime Database layout
The HTML stores leagues below `leagues/{leagueId}`. Source code reads/writes these fields or paths:

- `leagueName`: display name.
- `createdAt`: server timestamp used to order league lists.
- `isHidden`: whether a league appears in the public league list.
- `config`: league settings, including playersPerTeam, basePrice, startPoints, maxRetain, retainCost, numTeams, and auctionMode.
- `teamMeta`: configured team names/short names and legacy owner-password fields. The native app must not carry forward owner login/password functionality.
- `players`: player records and their auction status, team assignment, price, grade, role/contact/photo fields, and ordering/history attributes as applicable.
- `teams`: calculated/team state including IDs, names, colors, budget/credits, spend, player counts, and retention counts.
- `stage`: active auction stage/current player/current bid/selected team and bid log data.
- `bidCounter`, `retainCounter`, `adminUpdateCount`: counters.
- `lastEvent`: latest event marker.
- `history`: undo snapshots for auction/retention actions.
- `settings`: additional league settings, including grade configuration in the source.

The exact full field schema and all write paths still require a full native parity audit. Do not treat this summary as a validated migration schema.

## Native implementation rules
1. Do not wipe, rename, or migrate live Firebase data during initial setup.
2. Keep the existing league data shape compatible unless a migration is designed, reviewed, and tested against a backup.
3. Remove owner/viewer/online-bidding access flows in the app; do not simply hide their buttons while leaving alternate entry points.
4. Firebase persistence/sync is separate from remote bidding. Native app actions are controlled by the signed-in Admin.
5. Review Firebase Authentication configuration and Realtime Database/Storage security rules before production use. The client-side Firebase config in an HTML app is not an authorization boundary; database rules must enforce access.
6. Do not put service-account credentials or private signing material in the app or repository.

## Not yet verified
- Current Firebase Auth provider/users and the intended single-admin account setup.
- Realtime Database and Storage security rules.
- Full player/team/stage schema and edge cases across backup/restore.
- Whether player photos are stored as URLs or Firebase Storage objects in every flow.
- Any existing data requiring backward compatibility tests.
