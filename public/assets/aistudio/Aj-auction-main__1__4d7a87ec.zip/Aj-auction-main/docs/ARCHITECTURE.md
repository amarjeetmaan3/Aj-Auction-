# Native Android architecture

## Target stack
- Kotlin
- Jetpack Compose for native screens (no WebView)
- Material 3 components
- Repository/data layer separated from UI
- Firebase Authentication and Realtime Database integration only after the existing Firebase schema and access rules are verified

## Planned modules/layers
- `ui/`: Login, League list/setup, Teams, Players, Live Auction, Team Squads, Reports, Settings
- `domain/`: auction rules, bid/credit calculations, retention, SOLD/UNSOLD, undo and reset rules
- `data/`: Firebase repositories, local state/cache, JSON backup/restore
- `reports/`: PDF generation and player/team image cards
- `security/`: Admin-only authentication and session handling

## Product flow
1. Admin signs in.
2. Admin selects or creates a league.
3. Admin configures teams, players, grades, starting points, base price and retention settings.
4. Admin runs the in-person auction and manually controls bid amount and SOLD/UNSOLD state.
5. Admin reviews squad/bid history and exports PDF/images or backup.

## Excluded flows
- Team Owner login
- Online bidding / owner bid controls
- Viewer mode

## Data safety
- Firebase persistence/sync may remain enabled; it is independent of online bidding.
- No automatic database reset, deletion, or schema migration until the existing schema and data are reviewed.
- Do not embed service-role credentials or private keys in the app.
